module.exports = 'Gestión del talento humano según estructura organizacional'
