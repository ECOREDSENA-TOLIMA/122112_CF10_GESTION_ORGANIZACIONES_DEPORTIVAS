<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido(data-aos="flip-up")
      .titulo-principal__numero
        span 4
      h1 Aplicación del programa de gestión de talento humano
    
    .row.mt-5
      .col-lg-4.mb-4.mb-lg-0(data-aos="fade-right")
        figure.m-auto.col-7.col-md-7.col-lg-12
          img(src="@/assets/curso/tema4/1.png")
      .col-lg-8(data-aos="fade-left")
        p El programa de gestión del talento humano es un conjunto integrado de procesos de la organización, diseñado para atraer, gestionar, desarrollar, motivar y retener a los colaboradores. El programa se orienta a aprovechar al máximo el recurso humano para dar cumplimiento a las estrategias organizacionales. Este es considerado el recurso más importante en la organización, es el soporte fundamental para apalancar el negocio, la estructura, la estrategia y los procesos. Por ende, es el eje principal para que la empresa alcance sus objetivos.   
        .cajon.color-primario.p-4.mt-4(style="background-color:#DFE5FF;" data-aos="flip-up")
          p.mb-0 El programa será conforme a las necesidades, características y recursos de la organización. A continuación, se presentan los elementos más relevantes que deberá cumplir el programa de gestión del talento humano.
    
    .row.mt-5
      .col-lg-7.mb-4.mb-lg-0(data-aos="fade-right")
        LineaTiempoD.color-secundario
          .text-small(numero="1" titulo="Estructura organizacional enfocada al cumplimiento de los objetivos de la organización") 
            p.mt-3 Enfoque por gestión de procesos alineados a la estrategia organizacional. Desarrollo de un sistema de comunicaciones.
          .text-small(numero="2" titulo="Objetivos estratégicos apalancados por los talentos de las personas") 
            ul.lista-ul--separador.mb-0.mt-4
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Definición de objetivos estratégicos apalancados en las personas y los equipos.
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Definición de planes de desarrollo de talento humano que apalanquen la estrategia.
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Definición de plan estratégico con objetivos y metas claras para el talento humano.
              li.mb-4.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Proceso de despliegue de las competencias del negocio hasta los niveles operativos.
          .text-small(numero="3" titulo="Programa de desarrollo de las capacidades y del potencial del talento humano de acuerdo con las competencias del negocio") 
            ul.lista-ul--separador.mb-0.mt-4
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Gestión de planes de desarrollo (plan carrera) de las capacidades de las personas a nivel gerencia.
              li.mb-4.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Nivel de aplicación de normas técnicas sectoriales para el desarrollo de competencias técnicas operativas.
          .text-small(numero="4" titulo="Clima organizacional ") 
            ul.lista-ul--separador.mb-0.mt-4
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Cultura de Medición de clima laboral como palanca estratégica.
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Desarrollo de programas para mejorar el clima laboral.
              li.mb-4.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Nivel de implementación del control de los riesgos que afectan la salud y seguridad del talento humano.
          .text-small(numero="5" titulo="Responsabilidad social ") 
            ul.lista-ul--separador.mb-0.mt-4
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Desarrollo de programas de mejoramiento del entorno familiar del talento humano para incentivar su productividad.
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Desarrollo de un sistema de contratación formal que genere bienestar y productividad de los trabajadores.
              li.mb-4.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Desarrollo del sistema de reconocimiento y retribución de la generación de ideas y sugerencias de mejora en el nivel operativo.
      .col-lg-5(data-aos="fade-left")
        figure.m-auto.col-7.col-md-7.col-lg-12
          img(src="@/assets/curso/tema4/2.png")
    
    .row.mt-5
      .col-lg-5.mb-4.mb-lg-0(data-aos="fade-right")
        figure.m-auto.col-7.col-md-7.col-lg-12
          img(src="@/assets/curso/tema4/3.png")
      .col-lg-7(data-aos="fade-left")
        LineaTiempoD.color-secundario
          .text-small(numero="1" titulo="Objetivos estratégicos apalancados por los talentos de las personas") 
            ul.lista-ul--separador.mb-0.mt-4
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Cultura de Medición de clima laboral como palanca estratégica.
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Desarrollo de programas para mejorar el clima laboral.
              li.mb-4.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Nivel de implementación del control de los riesgos que afectan la salud y seguridad del talento humano.
          .text-small(numero="2" titulo="Responsabilidad social ") 
            ul.lista-ul--separador.mb-0.mt-4
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Desarrollo de programas de mejoramiento del entorno familiar del talento humano para incentivar su productividad.
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Desarrollo de un sistema de contratación formal que genere bienestar y productividad de los trabajadores.
              li.mb-4.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Desarrollo del sistema de reconocimiento y retribución de la generación de ideas y sugerencias de mejora en el nivel operativo.
          .text-small(numero="3" titulo="Fomento de la cultura organizacional de comunicación abierta, alto desempeño en el trabajo y alto compromiso de las personas ") 
            ul.lista-ul--separador.mb-0.mt-4
              li.mb-2.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Desarrollo de una cultura de control y seguimiento periódico al logro de sus resultados Nivel de desarrollo del sistema de recompensas para el personal gerencial basado en el desempeño.
              li.mb-4.d-flex
                i.fas.fa-angle-right(style="color:#FE502D;")
                div Nivel de desarrollo del sistema de recompensas para el personal operativo basado en el desempeño.



      




 

      
      
</template>

<script>
export default {
  name: 'Tema4',
  data: () => ({
    indicadorTarjetaFlip: true,
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>
<style lang="sass">
.lista-ol--separador li, .lista-ul--separador li
  border-style: dotted
</style>
